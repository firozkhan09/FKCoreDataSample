//
//  Developer.h
//  
//
//  Created by Santosh Narawade on 10/04/16.
//
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface Developer : NSManagedObject

@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) NSString * designation;
@property (nonatomic, retain) NSNumber * age;

@end
