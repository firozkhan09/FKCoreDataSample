//
//  Developer.m
//  
//
//  Created by Santosh Narawade on 10/04/16.
//
//

#import "Developer.h"


@implementation Developer

@dynamic name;
@dynamic designation;
@dynamic age;

@end
