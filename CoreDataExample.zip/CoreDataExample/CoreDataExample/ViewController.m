//
//  ViewController.m
//  CoreDataExample
//
//  Created by Santosh Narawade on 10/04/16.
//  Copyright (c) 2016 Santosh Narawade. All rights reserved.
//

#import "ViewController.h"
#import "Developer.h"
#import "AppDelegate.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
  [super viewDidLoad];
  // Do any additional setup after loading the view, typically from a nib.
  
  NSLog(@"%@", NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0]);
  
  AppDelegate *appDelegate = [UIApplication sharedApplication].delegate;
  
  // save
  Developer *developerManagedObject = [NSEntityDescription insertNewObjectForEntityForName:@"Developer" inManagedObjectContext:appDelegate.managedObjectContext];
  developerManagedObject.name = @"firoz";
  developerManagedObject.age = @26;
  developerManagedObject.designation = @"iOS Dev";
  
  NSError *error = nil;
  BOOL success = [appDelegate.managedObjectContext save:&error];
  if (!success || error) {
    NSLog(@"error saving: %@", error.localizedDescription);
  }
  
  // select / find
  NSFetchRequest *fetchRequest = [NSFetchRequest fetchRequestWithEntityName:@"Developer"];
  NSPredicate *predicate = [NSPredicate predicateWithFormat:@"name == 'firoz'"];
  fetchRequest.predicate = predicate;
  
  NSSortDescriptor *sortDesc = [NSSortDescriptor sortDescriptorWithKey:@"name" ascending:YES];
  fetchRequest.sortDescriptors = @[sortDesc];
  
  NSArray *result = [appDelegate.managedObjectContext executeFetchRequest:fetchRequest error:&error];
  if (!result.count || error) {
    NSLog(@"error finding: %@", error.localizedDescription);
  }
  NSLog(@"%@", [result valueForKey:@"name"]);
  
  // delete
  Developer *firozManagedObject = result[0];
  [appDelegate.managedObjectContext deleteObject:firozManagedObject];
}

- (void)didReceiveMemoryWarning {
  [super didReceiveMemoryWarning];
  // Dispose of any resources that can be recreated.
}

@end
